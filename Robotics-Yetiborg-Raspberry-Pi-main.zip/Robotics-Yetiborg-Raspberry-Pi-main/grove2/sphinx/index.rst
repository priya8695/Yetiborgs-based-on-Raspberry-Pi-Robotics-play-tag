.. grove.py documentation master file, created by
   sphinx-quickstart on Thu Feb 14 13:52:24 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to grove.py's documentation!
====================================

.. toctree::
   :hidden:
   :maxdepth: 4

.. .. include:: modules.rst
.. include:: grove.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

